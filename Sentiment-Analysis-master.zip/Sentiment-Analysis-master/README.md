# Sentiment-Analysis
Sentiment Analysis Using R and its packages including Shiny Application
